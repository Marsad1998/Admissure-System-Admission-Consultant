Please Wait
<?php include_once '../connect/db.php';
session_destroy();
redirect("login.php",1500);
?>